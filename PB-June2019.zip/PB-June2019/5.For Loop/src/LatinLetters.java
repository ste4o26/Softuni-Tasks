public class LatinLetters {

    public static void main(String[] args) {

        for (char letter = 'a'; letter <= 'z' ; letter++) {
            System.out.println(letter);
        }
    }
}
