class CheckingAccount {
    #clientId;
    #email;
    #firstName;
    #lastName;

    constructor(clientId, email, firstName, lastName) {
        this.clientId = clientId;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    get clientId() {
        return this.#clientId;
    }

    set clientId(clientId) {
        let regex = /^\d{6}$/;
        if (!regex.test(clientId)) throw new TypeError('Client ID must be a 6-digit number');
        this.#clientId = clientId;
    }

    get email() {
        return this.#email;
    }

    set email(email) {
        let regex = /^\w+@[\w\\.]+$/;
        if (!regex.test(email)) throw new TypeError('Invalid e-mail');
        this.#email = email;
    }

    get firstName() {
        return this.#firstName;
    }

    set firstName(firstName) {
        let regex = /^\w+$/;
        if (firstName.length < 3 || firstName > 20) throw new TypeError('First name must be between 3 and 20 characters long');
        if (!regex.test(firstName)) throw new TypeError('First name must contain only Latin characters');
        this.#firstName = firstName;
    }

    get lastName() {
        return this.#lastName;
    }

    set lastName(lastName) {
        let regex = /^\w+$/;
        if (lastName.length < 3 || lastName > 20) throw new TypeError('Last name must be between 3 and 20 characters long');
        if (!regex.test(lastName)) throw new TypeError('Last name must contain only Latin characters');
        this.#lastName = lastName;
    }
}

// let acc = new CheckingAccount('1314', 'ivan@some.com', 'Ivan', 'Petrov');
// let acc = new CheckingAccount('131455', 'ivan@', 'Ivan', 'Petrov');
let acc = new CheckingAccount('131455', 'ivan@some.com', 'I', 'Petrov');