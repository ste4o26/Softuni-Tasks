class List {
    #ascendingComparator = (f, s) => f - s;

    constructor() {
        this.elements = [];
        this.size = 0;
    }

    add(element) {
        this.elements.push(element)
        this.size++;
        this.elements = this.elements.sort(this.#ascendingComparator);
    }

    remove(index) {
        if (index < 0 || index >= this.elements.length) throw new Error('Index out of bounds Error!');
        this.elements.splice(index, 1)
        this.size--;
        this.elements = this.elements.sort(this.#ascendingComparator);
    }

    get(index) {
        if (index < 0 || index >= this.elements.length) throw new Error('Index out of bounds Error!');
        return this.elements[index];
    }
}

function solve() {
    let list = new List();
    list.add(5);
    list.add(6);
    list.add(7);
    console.log(list.get(1));
    list.remove(1);
    console.log(list.get(1));
}

solve();