function solve(input, sortCriteria) {
    class Ticket {
        constructor(destination, price, status) {
            this.destination = destination;
            this.price = price;
            this.status = status;
        }
    }

    return [...input]
        .reduce((acc, line) => {
            let [destination, price, status] = line.split('|');
            acc.push(new Ticket(destination, Number(price), status));
            return acc;
        }, [])
        .sort((f, s) => {
            return typeof (f[sortCriteria]) === 'string' && typeof (s[sortCriteria]) === 'string' ?
                f[sortCriteria].localeCompare(s[sortCriteria]) :
                f[sortCriteria] - s[sortCriteria]
        });
}


console.log(
    solve(['Philadelphia|94.20|available',
        'New York City|95.99|available',
        'New York City|95.99|sold',
        'Boston|126.20|departed'],
        'destination')
);

// console.log(
//     solve(['Philadelphia|94.20|available',
//         'New York City|95.99|available',
//         'New York City|95.99|sold',
//         'Boston|126.20|departed'],
//         'price')
// );