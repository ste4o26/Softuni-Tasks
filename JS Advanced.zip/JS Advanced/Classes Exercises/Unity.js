class Rat {
    constructor(name) {
        this.name = name;
        this.unitedRats = [];
    }

    unite(rat) {
        if (Rat.name === rat.constructor.name) // same can be done with instanceof!
            this.unitedRats.push(rat);
    }

    getRats() {
        return this.unitedRats;
    }

    toString() {
        let result = this.unitedRats
            .map(rat => `##${rat.name}`)
            .join('\n');

        return `${this.name}\n${result}`.trim();
    }
}


function solve() {
    let firstRat = new Rat("Peter");
    console.log(firstRat.toString()); // Peter 

    console.log(firstRat.getRats()); // [] 

    firstRat.unite(new Rat("George"));
    firstRat.unite(new Rat("Alex"));

    console.log(firstRat.getRats());
    // [ Rat { name: 'George', unitedRats: [] }, 
    //  Rat { name: 'Alex', unitedRats: [] } ] 

    console.log(firstRat.toString());
}


solve();