function solve() {
   const firstPlayerDeck = document.querySelector('#player1Div');
   const secondPlayerDeck = document.querySelector('#player2Div');
   const cards = document.querySelector('.cards');
   let result = document.querySelector('#history');


   if (firstPlayerDeck === null || secondPlayerDeck === null || cards === null || result === null) {
      throw new Error('Something went wrong!');
   }

   const currendHandResult = {
      player1Div: document.querySelectorAll('span')[0],
      player2Div: document.querySelectorAll('span')[2]
   };

   const currentHand = {
      player1Div: undefined,
      player2Div: undefined
   };

   cards.addEventListener('click', e => {
      const t = e.target;
      let player = t.parentElement.id;
      let card = t.name;

      t.src = 'images/whiteCard.jpg';
      currendHandResult[player].textContent = card;
      currentHand[player] = t;

      let [first, _, second] = document.querySelectorAll('span');
      if (first.textContent !== '' && second.textContent !== '') {
         //judge raboti bez setTimeout no ne po lesno za debugvane taka!
         setTimeout(() => {
            first.textContent = '';
            second.textContent = '';
         }, 2000);

         let firstPlayerCard = currentHand.player1Div;
         let secondPlayerCard = currentHand.player2Div;

         changeBorderStyle(firstPlayerCard, secondPlayerCard);

         result.textContent = result.textContent.concat(`[${firstPlayerCard.name} vs ${secondPlayerCard.name}] `);
      }
   });

   function changeBorderStyle(firstPlayerCard, secondPlayerCard) {
      if (Number(firstPlayerCard.name) > Number(secondPlayerCard.name)) {
         firstPlayerCard.style.border = '2px solid green';
         secondPlayerCard.style.border = '2px solid red';

      } else if (Number(firstPlayerCard.name) < Number(secondPlayerCard.name)) {
         firstPlayerCard.style.border = '2px solid red';
         secondPlayerCard.style.border = '2px solid green';
      }
   }
}

