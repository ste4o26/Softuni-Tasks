function solve() {
   const shoppingCart = document.querySelector('.shopping-cart');
   const output = document.querySelector('textarea');
   const products = [];

   if (shoppingCart === null || output === null) {
      throw new Error('Something went wrong!');
   }

   shoppingCart.addEventListener('click', e => {
      const t = e.target;
      //ppc za zadachata ne e nujen switch case no ako se opitat da kliknat nqkude drugade shte izgurmi za tova se podsigurqvam
      //kum moeto az v budeshteto koeto chete tozi kod : nadqvam se da si izmislil po dobyr variant ot tozi grozen swich case :)
      switch (t.className) {
         case 'add-product':
            addProductToCart(t, products);
            break;

         case 'checkout':
            checkout(products);
            break;

         default:
            throw new Error('You have to click on Add or Checkout button to perform an action!');
      }
   });

   function checkout(products) {
      const productsNames = products
         .reduce((a, product) => {
            if (!a.includes(product.name)) {
               a.push(product.name);
            }

            return a;
         }, [])
         .join(', ');

      const totalPrice = products.reduce((a, b) => a + b.price, 0).toFixed(2);
      const result = `You bought ${productsNames} for ${totalPrice}.`;
      output.value = output.value.concat(result);

      const buttons = document.querySelectorAll('.add-product');
      buttons.forEach(item => item.disabled = true);
   }

   function addProductToCart(t, products) {
      const productData = Array
         .from(t.parentElement.parentElement.children)
         .filter(item => item.className === 'product-details' || item.className === 'product-line-price')
         .map(changeItemToItsFirstChildIfExists);

      const product = createProductFromData(productData);
      products.push(product);

      let result = `Added ${product.name} for ${product.price.toFixed(2)} to the cart.\n`
      output.value = output.value.concat(result);
   }

   function changeItemToItsFirstChildIfExists(item) {
      if (item.children.length > 0) {
         item = item.firstElementChild;
      }
      return item;
   }

   function createProductFromData(productData) {
      const product = {};
      product.name = productData[0].textContent;
      product.price = +productData[1].textContent;
      return product;
   }
}