function solve() {
    let button = document.querySelector('button');
    let input = document.querySelector('input');

    if (button === null || input === null) {
        throw new Error('Something went wrong!');
    }

    function addToDataBase() {
        let name = input.value.toLowerCase();
        if (name.trim() === '') {
            throw new Error('Something went wrong!');
        }

        name = name[0].toUpperCase() + name.slice(1);
        let index = name.charCodeAt(0) % 65;//tuka moje i s - vmesto %
        let li = document.getElementsByTagName('li')[index];

        li.textContent = [...li.textContent
            .split(', ')
            .filter(e => e !== ''), name]
            .join(', ');

        input.value = '';
    }

    button.addEventListener('click', addToDataBase);
}