function solve() {
    let caclulator = document.querySelector('#calculator');
    let expressionOutput = document.querySelector('#expressionOutput');
    let resultOutput = document.querySelector('#resultOutput');

    if (caclulator === null || expressionOutput === null || resultOutput === null) {
        throw new Error('Somethin went wrong!');
    }

    const specialSymbols = {
        '+': ' + ',
        '-': ' - ',
        '*': ' * ',
        '/': ' / ',
        '=': calculate,
        'Clear': clear
    };

    caclulator.addEventListener('click', e => {
        let t = e.target;

        if (t.nodeName === 'BUTTON') {
            switch (typeof (specialSymbols[t.value])) {
                case 'undefined':
                    expressionOutput.textContent += t.value;
                    break;

                case 'function':
                    specialSymbols[t.value](expressionOutput, resultOutput);
                    break;

                default:
                    expressionOutput.textContent += specialSymbols[t.value];
                    break;
            }
        }
    });

    function calculate(expressionOutput, resultOutput) {
        const operationsMap = {
            '+': (f, s) => f + s,
            '-': (f, s) => f - s,
            '*': (f, s) => f * s,
            '/': (f, s) => f / s
        };

        let operation = expressionOutput.textContent.match(/[+]|[-]|[*]|[/]/);
        let [first, second] = expressionOutput.textContent.split(` ${operation} `);

        first === '' || second === '' ?
            resultOutput.textContent = 'NaN' :
            resultOutput.textContent = operationsMap[operation](+first, +second);
    }

    function clear(expressionOutput, resultOutput) {
        expressionOutput.textContent = '';
        resultOutput.textContent = '';
    }
}