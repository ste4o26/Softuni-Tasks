function solve() {
  const correctAnswers = ['onclick', 'JSON.stringify()', 'A programming API for HTML and XML documents'];
  const myAnswers = [];

  let div = document.querySelector('#quizzie');


  div.addEventListener('click', e => {
    let t = e.target;
    if (t.className.trim() === 'answer-text') {
      let answer = t.textContent;
      addAnswerIfCorrect(correctAnswers, answer, myAnswers);
      changeQuizz(t, correctAnswers, myAnswers);
    }
  });

  function changeQuizz(target, correctAnswers, myAnswers) {
    let currentQuizz = target.parentElement.parentElement.parentElement.parentElement;
    let nextQuizz = target.parentElement.parentElement.parentElement.parentElement.nextElementSibling;

    if (currentQuizz !== null && nextQuizz !== null) {
      currentQuizz.style.display = 'none';
      nextQuizz.style.display = 'block';
      printResult(myAnswers, correctAnswers);
    }
  }

  function addAnswerIfCorrect(correctAnswers, answer, myAnswers) {
    if (correctAnswers.includes(answer)) {
      myAnswers.push(answer);
    }
  }

  function printResult(myAnswers, correctAnswers) {
    let output = document.getElementById('results').firstElementChild.firstElementChild;

    if (myAnswers.length === correctAnswers.length) {
      output.textContent = 'You are recognized as top JavaScript fan!';
    } else {
      output.textContent = `You have ${myAnswers.length} right answers`;
    }
  }
}

