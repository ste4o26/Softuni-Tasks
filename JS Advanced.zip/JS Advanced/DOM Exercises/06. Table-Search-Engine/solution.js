function solve() {
   let input = document.getElementById('searchField');
   let button = document.getElementById('searchBtn');
   let table = document.querySelector('tbody');

   if (input === null || button === null || table === null) {
      throw new Error('Something went wrong!');
   }

   button.addEventListener('click', e => {
      if (input.value === '') {
         throw new Error('You cannot search for empty string in the table!')
      }

      let rows = Array.from(table.children);
      rows
         .filter(row => row.className === 'select')
         .map(row => row.className = '');

      rows
         .filter(row => row.textContent.includes(input.value))
         .map(row => row.className = 'select');

      input.value = '';
   });
}