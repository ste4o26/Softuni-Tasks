function solve() {
    let input = document.getElementById('input');
    let selectMenu = document.getElementById('selectMenuTo');
    let convertButton = document.getElementsByTagName('button')[0];
    let outputResult = document.getElementById('result');

    if (input === null || selectMenu === null || convertButton === null || outputResult === null) {
        throw new Error('Something went wrong!');
    }

    addOptionsToMenu(selectMenu);
    convertButton.addEventListener('click', displayResult(selectMenu, outputResult, input));


    function displayResult(selectMenu, outputResult, input) {
        const options = {
            binary: (x) => x.toString(2),
            hexadecimal: (x) => x.toString(16).toUpperCase()
        };

        return function () {
            let number = Number(input.value);
            let selectedOption = selectMenu.options[selectMenu.selectedIndex].value;
            outputResult.value = options[selectedOption](number);
        }
    }

    function addOptionsToMenu(selectMenu) {
        let optionHex = document.createElement('option');
        let optionBin = document.createElement('option');

        optionHex.value = 'hexadecimal';
        optionBin.value = 'binary';

        optionHex.textContent = 'Hexadecimal';
        optionBin.textContent = 'Binary';

        selectMenu.appendChild(optionHex);
        selectMenu.appendChild(optionBin);
    }
}
