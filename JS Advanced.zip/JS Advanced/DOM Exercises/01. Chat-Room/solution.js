function solve() {
   let textarea = document.getElementById('chat_input');
   let chatMessages = document.getElementById('chat_messages');
   let sendButton = document.getElementById('send');

   if (textarea === null || chatMessages === null || sendButton === null) {
      throw new Error('Something went wrong!');
   }

   sendButton.addEventListener('click', sendMessage(textarea, chatMessages));

   function sendMessage(textarea, chatMessages) {
      return function () {
         if (textarea.value === '') {
            return;
         }
         let div = document.createElement('div');
         div.className = 'message my-message';
         div.textContent = textarea.value;
         chatMessages.appendChild(div);
         textarea.value = '';
      }
   }
}



