function solve() {
  const textarea = document.querySelector('textarea');
  const table = document.querySelector('tbody');
  const outputTextarea = document.querySelectorAll('textarea')[1];
  let [generateBtn, buyBtn] = document.querySelectorAll('button');


  if (textarea === null || generateBtn === null || buyBtn === null || table === null || outputTextarea === null) {
    throw new Error('Something went wrong!');
  }

  generateBtn.addEventListener('click', e => {
    const furnitures = JSON.parse(textarea.value);
    createRow(furnitures);
  });

  buyBtn.addEventListener('click', e => {
    const rows = document.querySelectorAll('tbody tr');
    buyCheckedFurnitures(rows);

  });

  function createRow(furnitures) {

    furnitures.forEach(furniture => {
      const tr = document.createElement('tr');
      table.appendChild(tr);

      let tdImg = document.createElement('td');
      tdImg.innerHTML = `<img src="${furniture.img}">`
      tr.appendChild(tdImg);

      Object.keys(furniture)
        .filter(key => key !== 'img')
        .map(key => {
          const td = document.createElement('td');
          const p = document.createElement('p');

          p.textContent = furniture[key];
          td.appendChild(p);
          tr.appendChild(td);
        });

      let tdCheckbox = document.createElement('td');
      tdCheckbox.innerHTML = '<input type="checkbox">';
      tr.appendChild(tdCheckbox);
    });
  }

  function buyCheckedFurnitures(rows) {
    const checkedFurnitures = Array.from(rows)
      .filter(item => item.lastElementChild.firstElementChild.checked);

    let names = Array.from(checkedFurnitures)
      .reduce((a, b) => {
        a.push(b.children[1].firstElementChild.textContent)
        return a;
      }, [])
      .join(', ');

    let totalPrice = checkedFurnitures
      .reduce((a, b) => a + +b.children[2].firstElementChild.textContent, 0);

    let avgDecFactor = checkedFurnitures
      .reduce((a, b) => a + +b.children[3].firstElementChild.textContent, 0) / checkedFurnitures.length

    let result = `Bought furniture: ${names}\nTotal price: ${totalPrice.toFixed(2)}\nAverage decoration factor: ${avgDecFactor}`;
    outputTextarea.value = outputTextarea.value.concat(result);
  }
}