class Circle {
    constructor(radius) {
        this.radius = radius;
    }

    get diameter() {
        return this.radius * 2;
    }

    set diameter(diameter) {
        this.radius = diameter / 2;
    }

    area() {
        return Math.pow(this.radius, 2) * Math.PI;
    }
}

function solve() {
    const circle = new Circle(2);

    console.log(`Radius: ${circle.radius}`);
    console.log(`Diameter: ${circle.diameter}`);
    console.log(`Area: ${circle.area()}`);

    circle.diameter = 1.6;

    console.log(`Radius: ${circle.radius}`);
    console.log(`Diameter: ${circle.diameter}`);
    console.log(`Area: ${circle.area()}`);
}

solve();