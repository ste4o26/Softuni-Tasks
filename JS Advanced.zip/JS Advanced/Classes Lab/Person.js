class Person {
    constructor(firstName, lastName, age, email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.email = email;
    }

    toString() {
        return `${this.firstName} ${this.lastName} (age: ${this.age}, email: ${this.email})`
    }
}

function solve() {
    const people = [];

    people.push(new Person('Stephan', 'Johnson', 25, ''));
    people.push(new Person('Anna', 'Simpson', 22, 'anna@yahoo.com'));
    people.push(new Person('', '', '', ''));
    people.push(new Person('Gabriel', 'Peterson', 24, 'g.p@gmail.com'));

    people.forEach(person => console.log(person.toString()));
}

solve();
//tova sa 2ra i 3ta zadacha ot laba
