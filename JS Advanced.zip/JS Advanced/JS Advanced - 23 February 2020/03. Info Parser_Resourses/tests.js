let Parser = require("./solution.js");
let assert = require("chai").assert;
describe("MyTests", () => {
    //ToDO
});