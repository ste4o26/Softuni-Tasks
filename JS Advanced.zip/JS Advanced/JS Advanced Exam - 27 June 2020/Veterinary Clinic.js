class VeterinaryClinic {
    constructor(clinicName, capacity) {
        this.clinicName = clinicName;
        this.capacity = capacity;
        this.clients = [];
        this.currentWorkload = 0;
        this.totalProfit = 0;
        //totalProfit and currentWorkload may have to add thouse properties
    }

    newCustomer(ownerName, petName, kind, procedures) {
        if (this.currentWorkload + 1 > this.capacity) { throw new Error('Sorry, we are not able to accept more patients!') }

        //moje da imam problem tuka!!!
        let client = this.clients.find(client => client.ownerName === ownerName);
        if (client !== undefined) {
            let pet = client.pets.find(pet => pet.petName === petName);
            if (pet !== undefined && pet.procedures.length !== 0) {
                throw new Error(`This pet is already registered under ${ownerName} name! ${petName} is on our lists, waiting for ${pet.procedures.join(', ')}.`)
            }
            //moje da se naloji da proverqvam dali pet === undefine
        } else {
            client = {
                ownerName: ownerName,
                pets: []
            };
            this.clients.push(client);
        }

        let newPet = {
            petName: petName,
            kind: kind,
            procedures: procedures//array
        };

        client.pets.push(newPet);
        this.currentWorkload++;
        return `Welcome ${petName}!`;
    }

    onLeaving(ownerName, petName) {
        let client = this.clients.find(client => client.ownerName === ownerName);
        if (client === undefined) { throw new Error('Sorry, there is no such client!') }

        let pet = client.pets.find(pet => pet.petName === petName);
        if ((pet === undefined) || (pet !== undefined && pet.procedures.length === 0)) { throw new Error(`Sorry, there are no procedures for ${petName}!`) }

        pet.procedures.forEach(procedure => this.totalProfit += 500);
        pet.procedures = [];
        this.currentWorkload--;

        return `Goodbye ${petName}. Stay safe!`;
    }

    toString() {
        let percentagesOfBusyness = Math.ceil((this.currentWorkload / this.capacity) * 100);

        let result = `${this.clinicName} is ${percentagesOfBusyness}% busy today!\nTotal profit: ${this.totalProfit.toFixed(2)}$\n`;

        this.clients
            .sort((f, s) => f.ownerName.localeCompare(s.ownerName))
            .map(client => {
                result = result.concat(`${client.ownerName} with:\n`);
                client.pets
                    .sort((f, s) => f.petName.localeCompare(s.petName))
                    .map(pet => result = result.concat(`---${pet.petName} - a ${pet.kind.toLowerCase()} that needs: ${pet.procedures.join(', ')}\n`));
            });

        return result.trim();
    }
}

let clinic = new VeterinaryClinic('SoftCare', 10);

console.log(clinic.newCustomer('Jim Jones', 'Tom', 'Cat', ['A154B', '2C32B', '12CDB']));
console.log(clinic.newCustomer('Anna Morgan', 'Max', 'Dog', ['SK456', 'DFG45', 'KS456']));
console.log(clinic.newCustomer('Jim Jones', 'Tiny', 'Cat', ['A154B']));

console.log(clinic.onLeaving('Jim Jones', 'Tiny'));

console.log(clinic.toString());

clinic.newCustomer('Jim Jones', 'Sara', 'Dog', ['A154B']);

console.log(clinic.toString());

// console.log(
//     clinic.clients.forEach(client => client.pets.forEach(pet => console.log(pet.petName, pet.kind, pet.procedures)))
// );