package person_encapsulation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Team {

    private String name;
    private List<Person> firstTeam;
    private List<Person> reserveTeam;

    public Team(String teamName) {
        this.setTeamName(teamName);
        this.firstTeam = new ArrayList<>();
        this.reserveTeam = new ArrayList<>();
    }

    private void setTeamName(String teamName) {
        this.name = teamName;
    }

    public String getTeamName() {
        return name;
    }

    public void addPlayer(Person member) {
        if (member.getAge() < 40) {
            this.firstTeam.add(member);
        } else {
            this.reserveTeam.add(member);
        }
    }

    public List<Person> getFirstTeam() {
        return Collections.unmodifiableList(this.firstTeam);
    }

    public List<Person> getReserveTeam() {
        return Collections.unmodifiableList(this.reserveTeam);
    }
}
