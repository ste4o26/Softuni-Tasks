package wild_farm.foods;

public class Meat extends Food {

    public Meat(int foodQuantity) {
        super(foodQuantity);
    }
}
