package telephony.input_data_parser;

public class UrlsParser extends InputParser{
    public UrlsParser(String input) {
        super(input);
    }
}
