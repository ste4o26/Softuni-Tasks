package telephony.input_data_parser;

public class TelephoneNumberParser extends InputParser {
    public TelephoneNumberParser(String input) {
        super(input);
    }
}
