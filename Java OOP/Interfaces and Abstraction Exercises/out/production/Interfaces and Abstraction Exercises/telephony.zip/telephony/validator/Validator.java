package telephony.validator;

public interface Validator {

    //TODO CREATE MATCHER AND PATTERN IN SEPARATE CLASS AND VALIDATE TROUGH THEM ! ! !;
    void validate(String data);
}
