package telephony.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UrlValidator implements Validator {
    @Override
    public void validate(String url) {
        if (isUrlContainsDigit(url)){
            //throw new IllegalArgumentException("Invalid URL!");
            System.out.println("Invalid URL!");
        }
    }

    private boolean isUrlContainsDigit(String url) {
//        char[] urlSymbols = url.toCharArray();
//        for (int i = 0; i < urlSymbols.length; i++) {
//            char symbol = urlSymbols[i];
//            if (Character.isDigit(symbol)) {
//                return true;
//            }
//        }
//        return false;

        String regex = "\\d";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(url);
        if (matcher.find()){
            return true;
        }
        return false;
    }
}
