package telephony.smartphone;
import telephony.validator.CallsValidator;
import telephony.validator.UrlValidator;
import telephony.validator.Validator;

import java.util.List;

public class Smartphone implements Callable, Browsable {
    private List<String> numbers;
    private List<String> urls;
    private Validator validator;

    public Smartphone(List<String> numbers, List<String> urls) {
        this.numbers = numbers;
        this.urls = urls;
    }

    public List<String> getNumbers() {
        return this.numbers;
    }

    public List<String> getUrls() {
        return this.urls;
    }

    @Override
    public String browse() {
        this.validator = new UrlValidator();
        String url = this.urls.remove(0);
        validator.validate(url);
        return String.format("Browsing: %s!", url);
    }

    @Override
    public String call() {
        this.validator = new CallsValidator();
        String telephoneNumber = this.numbers.remove(0);
        validator.validate(telephoneNumber);
        return String.format("Calling... %s", telephoneNumber);
    }


}
