package telephony.smartphone;

public interface Callable {
    String call();
}
