package telephony.smartphone;

public interface Browsable {
    String browse();
}
