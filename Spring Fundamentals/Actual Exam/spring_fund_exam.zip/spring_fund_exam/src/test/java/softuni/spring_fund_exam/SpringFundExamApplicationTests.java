package softuni.spring_fund_exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFundExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
