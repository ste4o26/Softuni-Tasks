package softuni.spring_fund_exam.model.entities.enums;

public enum BandName {
    QUEEN,
    METALLICA,
    MADONNA;
}
