package softuni.spring_fund_exam.model.entities.enums;

public enum GenreName {
    POP,
    ROCK,
    METAL,
    OTHER;
}
