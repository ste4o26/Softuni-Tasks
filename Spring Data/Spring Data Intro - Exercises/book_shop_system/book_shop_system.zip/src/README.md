You dont have to make any changes to the file paths
 because the path is get via reflection from the resources package
 so it have to work on every computer without any changes at all!!!