package book_shop_system.domain.entities;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
