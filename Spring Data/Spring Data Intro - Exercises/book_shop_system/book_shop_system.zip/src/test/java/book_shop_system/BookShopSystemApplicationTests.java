package book_shop_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookShopSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
