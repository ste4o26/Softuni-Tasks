package entities.bills_payment_system;

public enum CardType {
    DEBIT,
    CREDIT,
    SAVING
}
