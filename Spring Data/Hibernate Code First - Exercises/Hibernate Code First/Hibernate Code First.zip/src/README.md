Comment the @Entity and @Table annotations 
on all packages except the one that you are 
about to test, to create only the entities for a certain tasks!!!

Also change the persistence unit in application class 
as well as in the persistence.xml file!!!