package List_Utilities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        List<String> stringList = new ArrayList<>();
        Collections.addAll(stringList, "Alice", "Bob", "Charlie", "Renka");
        System.out.println(ListUtils.getMin(stringList));
        System.out.println(ListUtils.getMax(stringList));


        List<Integer> integerList = new ArrayList<>();
        Collections.addAll(integerList, 1, 3, 5, 26, 8);
        System.out.println(ListUtils.getMin(integerList));
        System.out.println(ListUtils.getMax(integerList));

    }
}
