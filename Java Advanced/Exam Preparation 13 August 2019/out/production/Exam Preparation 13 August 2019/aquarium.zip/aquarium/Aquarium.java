package aquarium;

import java.util.LinkedHashMap;
import java.util.Map;

public class Aquarium {

    private Map<String, Fish> fishInPool;
    private String name;
    private int capacity;
    private int size;//volume

    public Aquarium(String name, int capacity, int size) {
        this.name = name;
        this.capacity = capacity;
        this.size = size;
        fishInPool = new LinkedHashMap<>();
    }

    public void add(Fish fish) {
        if (this.fishInPool.size() < this.getCapacity()){
            this.fishInPool.putIfAbsent(fish.getName(), fish);
        }
    }

    public boolean remove(String name) {
        if (this.fishInPool.containsKey(name)){
            this.fishInPool.remove(name);
            return true;
        }else {
            return false;
        }
    }

    public Fish findFish(String name) {
        return this.fishInPool.getOrDefault(name, null);
    }

    public String report() {
        StringBuilder result = new StringBuilder();
        result.append(String.format("Aquarium: %s ^ Size: %d%n", this.getName(), this.getSize()));
        this.fishInPool
                .values()
                .forEach(result::append);

        return result.toString();
    }

    public int getFishInPool() {
        return this.fishInPool.size();
    }

    public String getName() {
        return this.name;
    }

    public int getCapacity() {
        return this.capacity;
    }

    public int getSize() {
        return this.size;
    }
}
